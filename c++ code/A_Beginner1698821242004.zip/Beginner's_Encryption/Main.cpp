// Adam Boulfoul - "A Beginner's Simple Encryption Tutorial / Example" chebby_shabby@hotmail.com
/////////////////////////////////////////////////////////////////////////////////////////////////
// This is not an "uncrackable" type of encryption but once you can understand the basics of
// this type of file encryption you CAN make better ones than me. This is just a quick example
// of basic encryption. Highly commented to help beginners.
/////////////////////////////////////////////////////////////////////////////////////////////////
// Before we start:
// What this basic program does is simply getting a byte from a file then adding 25 to it
// (ofcouse you can change it to whatever you like).
/////////////////////////////////////////////////////////////////////////////////////////////////
// If you have any questions, my e-mail is above :)
/////////////////////////////////////////////////////////////////////////////////////////////////

#include	<iostream.h>	// We need this for input and output to the user
#include	<fstream.h>		// This is the header to read or write files
#include	<stdio.h>		// We only need this to delete a file using remove()
// As mentioned abode, we simply add 25 to a byte, change this to whatever you like.
#define		ENCRYPTION_FORMULA		(int) Byte + 25	
// The decryption formula is the opposite to encryption formula, every "+" is a "-"
#define		DECRYPTION_FORMULA		(int) Byte - 25

///////////////////////////////////////////////////////////////////////////////////////////
// TIP: Everytime you see ENCRYPTION_FORMULA ot DECRYPTION_FORMULA mensioned, highlight it
// then press on definition and it will bring you up here! (Only on Visual C++)
///////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
// Our main function, put this in your program, FILENAME is the file to encrypt
// and NEW_FILENAME is the new location of the encrypted file
/////////////////////////////////////////////////////////////////////////////////
											
int Encrypt (char * FILENAME, char * NEW_FILENAME)	
{
	ifstream inFile;	// This is the file that we're going to encrypt and read
	ofstream outFile;	// Once we encrypt the file, this is it's new location

	char Byte;			// This is the FILENAME's byte, we'll add 25 to this later

	///////////////////////////////////////////////////////////////
	// Before we continue:
	// ios:: in		-	 Used for reading a file
	// ios::out		-	 Used for writing a file
	// ios::binary	-	 Used for reading or writing binary files
	///////////////////////////////////////////////////////////////

	inFile.open(FILENAME, ios::in | ios::binary);		// We read this file in binary mode
	outFile.open(NEW_FILENAME, ios::out | ios::binary);	// And we write the file in binary mode

	// eof() stands for End Of File, so while we are still reading the file, continue
	while(!inFile.eof())	
	{
		// Remember we need to change a byte so we add 25 to it
		char NewByte;
		
		//////////////////////////////////////////////////
		// NOTE: Only use the .put() and .get() in loops	
		// because it only reads 1 Byte at a time!						
		//////////////////////////////////////////////////

		// Out old byte is recieved from the file
		Byte = inFile.get();	

		// If the file that we are reading has an error, turn 0
		if (inFile.fail())		
			return 0;
		//Remember our Encryption Formula above?
		//Our new byte is recieved from it, see above
		NewByte = ENCRYPTION_FORMULA;	
		// This simple puts the new byte, into the new file!
		outFile.put(NewByte);
	}

	// We have to be neat so we close both the file that we're reading
	// and the file that we're writing
	inFile.close();		// (File to read)
	outFile.close();	// (File to write)

	return 1; // Success!
}

///////////////////////////////////////////////////////////////////////////////
// What's the point of encrypting a file if you can't decrypt it?
// If you're wondering why this is not commented it's because I've already
// explained everything above, notice that everything is the same except for
// two lines!
///////////////////////////////////////////////////////////////////////////////

int Decrypt (char * FILENAME, char * NEW_FILENAME)	
{
	ifstream inFile;
	ofstream outFile;

	char Byte;

	inFile.open(FILENAME, ios::in | ios::binary);
	outFile.open(NEW_FILENAME, ios::out | ios::binary);

	while(!inFile.eof())	
	{
		char NewByte;
		
		Byte = inFile.get();	

		if (inFile.fail())		
			return 0;
									  /////////////////////////////////////////////////////
		NewByte = DECRYPTION_FORMULA; // New Line! We just change the ENCRYPTION_FORMULA
									  // to DECRYPTION_FORMULA, see above
									  /////////////////////////////////////////////////////
		outFile.put(NewByte);
	}

	inFile.close();
	outFile.close();

	return 1;
}

///////////////////////////////////////////////////////////////////////
// WARNING: If you choose to decrypt a file that it already decrypted
// then the file would be encrypted!
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
// To use the functions in your program (doesn't have to be a DOS program),
// copy the 2 functions above, this is just an example, in the example I'm
// encrypting
///////////////////////////////////////////////////////////////////////////////////

int main()
{
	///////////////////////////////////////////////////////////////////
	// The functions can be used in not only DOS programs
	// Since this is an example, I'll show you how to use them :)
	///////////////////////////////////////////////////////////////////

	char EncFile[200];		// This is the string for the file to be encrypted
	char NewEncFile[200];	// This is the new location of the encrypted file

	char DecFile[200];		// This is the string for the file to be decrypted
	char NewDecFile[200];	// This is the new location of the decrypted file

	int Choice;				//The user's choice variable (1 = Encrypt 2 = Decrypt)

	// In case you didn't know, all these "cout" just display a message
	// Cin tells the user to input something
	cout << "NOTE: You must encrypt the file with the same file extension!"<<endl;
	cout << "Enter 1 to Encrypt / 2 to Decrypt"<<endl;
	cin >> Choice;	// In this case, our input is the user's choice 

	switch(Choice)
	{
	case 1:	// Did the user choose to  encrypt a file?
		cout << "Enter the current Filename:    ";
		cin >> EncFile;	// The user's input for the current file to be encrypted

		cout << "Enter the new Filename:	";
		cin >> NewEncFile;	//The user's input for the new location of the encrypted file

		Encrypt(EncFile, NewEncFile);	/*********** ENCRYPT FUNCTION ************/
		break;

	case 2:	// Or did the user choose to decrypt a file?
		cout << "Enter the current Filename:    ";
		cin >> DecFile;	//Already explained but with the decrypted file this time!

		cout << "Enter the new Filename:	";
		cin >> NewDecFile;

		Decrypt(DecFile, NewDecFile);	/*********** DECRYPT FUNCTION ************/
		break;
	}


	return 0;	//Exit!
}

//////////////////////////////////////////////////////////////////////////////////
// That's it! Looks so long yet it's so simple and easy to understand!
//////////////////////////////////////////////////////////////////////////////////
// So what we basicly done is open a file and add 25 to every byte of the file!
// Very simple!
//////////////////////////////////////////////////////////////////////////////////
// Any questions to chebby_shabby@hotmail.com
// If this tutorial is successful then my next tutorial is
// "A Beginner's Simple Compression Tutorial / Example
//////////////////////////////////////////////////////////////////////////////////
// by Adam Boulfoul
//////////////////////////////////////////////////////////////////////////////////