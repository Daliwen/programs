#include <iostream>
#include <conio.h>
#include <string>

using namespace std;

const int PASSLEN = 20;

string passget();

int main()
{
	string password;
	cout << "Password: ";
	password = passget();
	cout << endl << password;
	getch();
}

string passget()
{
	char password[PASSLEN], letter;
	int loop;
	int len;
	string password2;

		//Get Password and replace letters with *--------------
		loop = 0;
		while(loop != PASSLEN)
		{
			password[loop] = '\0';
			loop++;
		}
		loop = 0;
		len = 0;
		letter = '\0';
		while( letter != '\r' )
		{
			letter = getch();
			if( letter == '\b' && password[0] == '\0')
			{
				loop = 0;
				len = 0;
			}
			else 
			{
				if( letter == '\b' && password[0] != '\0')
				{
					cout << "\b";
					cout << " ";
					cout << "\b"; 
					loop--;
					password[loop] = '\0';
					len--;
				}
				else 
				{
					if( isprint( letter ) != 0 && loop < PASSLEN)
					{
						password[loop] = tolower(letter);
						cout << "*" ;
					}
					loop++;
					if (loop <= PASSLEN)
						len++;
				}
			}
		}
		
		//Convert Password from character array to string-----------
		loop = 0;
		len = len;
		password2 = "";
		while (loop != len)
		{
		password2 = password2+password[loop];
		loop++;
		}

	return password2;
}